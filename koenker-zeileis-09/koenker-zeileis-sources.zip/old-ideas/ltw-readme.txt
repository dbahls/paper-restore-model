Helmut L�tkepohl, Timo Ter�svirta, and J�rgen Wolters, "Investigating
Stability and Linearity of a German M1 Money Demand Function", Journal
of Applied Econometrics, Vol. 14, No. 5, 1999, pp. 511-525.

The data are in the file ltw-data.dat, which is in DOS format and is zipped
in the file ltw-data.zip.

Characteristics of the data:

frequency:	quarterly
format:		ASCII, decimals separated by .
dimension:	each dataset is a single row
last update:	05-24-1997


name:		Lm1b
definition:	log(M1/P*N)
description:	real M1 per capita, M1 seasonally unadjusted, nominal, 
                1960(1)-1990(2) West Germany, 1990(3)-1995(4) whole Germany 
observations:	1960(1)-1995(4), T=144
source:		Monatsberichte der Deutschen Bundesbank

name:		Lp
definition:	log(P)
description:	P, index of implicit price deflator of gross national product, 
                1985=100
observations:	1960(1)-1996(2), T=146
source:		Deutsches Institut fuer Wirtschaftsforschung, 
                Volkswirtschaftliche Gesamtrechnung

name:		Lyrb
definition:	log(Y/P*N)
description:	real gross national product per capita
		1. Y 1960(1)-1995(4) gross national product of West Germany
		2. Y 1990(3)-1995(4) gross national product of East Germany 
		(New Laender)
		semiannual, quarterly frequency of GNP for Germany from 
		1990(3) constructed
observations:	1960(1)-1995(4), T=144
source:		1. Deutsches Institut fuer Wirtschaftsforschung, 
                Volkswirtschaftliche Gesamtrechnung
		2. Sachverstaendigenrat (1994)
		
name:		Lyrbd
definition:	d90(3)*log(Y/P*N)
description:	real gross national product per capita from 1990(3) onward 
                (see Lyrb)
observations:	1960(1)-1995(4), T=144
source:		see Lyrb

name:		Glr
description:	r, long-run interest rate, Umlaufsrendite
observations:	1960(1)-1996(3), T=147
source:		Monatsberichte der Deutschen Bundesbank

name:		S1
definition:	D1, seasonal dummy 1st quarter
observations:	1960(1)-1996(4), T=148

name:		S1d
definition:	D1star = d90(3)*D1
observations:	1960(1)-1996(4), T=148

name:		S2
definition:	D2, seasonal dummy 2nd quarter
observations:	1960(1)-1996(4), T=148

name:		S2d
definition:	D2star = d90(3)*D2
observations:	1960(1)-1996(4), T=148

name:		S3
definition:	D3, seasonal dummy 3rd quarter
observations:	1960(1)-1996(4), T=148

name:		S3d
definition:	D3star = d90(3)*D3
observations:	1960(1)-1996(4), T=148


others (not in file)

Population figure N
source:		Wirtschaft und Statistik

d90(3)=1 from 1990(3) onward, 0 for other observations.
