Shiferaw Gurmu, "Semiparametric Estimation of Hurdle Regression Models
With an Application to Medicaid Utilization", Journal of Applied
Econometrics, Vol. 12, No. 3, 1997, pp. 225-242.

The file sg.zip contains the ASCII file sg.dat, which is in DOS format.
It consists of 996 observations on 13 variables. Columns of the data
represent variables.  Rows 1-485 (486-996) are for the AFDC (SSI)
sample. Data are taken from the 1986 Medicaid Consumer Survey sponsored
by the Health Care Financing Administration. 

The variables appear in the order given below.

 1. Doctor visits
 2. Exposure
 3. Children
 4. Age
 5. Income times 1000
 6. Access
 7. PC1 times 1000
 8. PC2 times 1000
 9. Marital Status
10. Sex (1 = female)
11. Race
12. School
13. Enroll

